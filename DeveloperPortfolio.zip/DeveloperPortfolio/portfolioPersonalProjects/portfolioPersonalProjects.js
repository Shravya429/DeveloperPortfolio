import { LightningElement } from "lwc";
import PortfolioAssets from "@salesforce/resourceUrl/PortfolioAssets";
export default class PortfolioPersonalProjects extends LightningElement {
  BMICalculator = `${PortfolioAssets}/PortfolioAssets/Projects/BMICalculator.png`;
  AlarmClock = `${PortfolioAssets}/PortfolioAssets/Projects/AlarmClock.png`;
  WeatherApp = `${PortfolioAssets}/PortfolioAssets/Projects/WeatherApp.png`;
  SurveyApp = `${PortfolioAssets}/PortfolioAssets/Projects/Survey.png`;

  projects = [
    {
      name: "BMI Calculator App",
      img: this.BMICalculator,
      link: "https://shravyaportfolio-a-dev-ed.develop.my.site.com/bmi-calculator",
    },
    {
      name: "Alarm Clock App",
      img: this.AlarmClock,
      link: "https://shravyaportfolio-a-dev-ed.develop.my.site.com/alarm-clock",
    },
    {
      name: "Weather App",
      img: this.WeatherApp,
      link: "https://shravyaportfolio-a-dev-ed.develop.my.site.com/weather-app",
    },
    {
      name: "Survey App",
      img: this.SurveyApp,
      link: "https://shravyaportfolio-a-dev-ed.develop.my.site.com/survey/survey/runtimeApp.app?invitationId=0Kiaj0000001YCX&surveyName=employee_survey&UUID=102492a7-e590-441e-9229-2a5511b3b4fb",
    },
  ];
}
