import { LightningElement, wire, api } from "lwc";
import PortfolioAssets from "@salesforce/resourceUrl/PortfolioAssets";
import { getRecord, getFieldValue } from "lightning/uiRecordApi";
import FULLNAME from "@salesforce/schema/Portfolio__c.FullName__c";
import COMPANY_LOCATION from "@salesforce/schema/Portfolio__c.CompanyLocation__c";
import COMPANY_NAME from "@salesforce/schema/Portfolio__c.CompanyName__c";
import DESIGNATION from "@salesforce/schema/Portfolio__c.Designation__c";

export default class PortfolioBanner extends LightningElement {
  @api recordId; //= "a0Aaj000000wuY6EAI";
  @api linkedinUrl; //= "https://www.linkedin.com/in/shravya-parusha-a505401a7/";
  @api twitterUrl; //= "https://x.com/SParusha444";
  @api githubUrl; //= "https://github.com/Shravya429";
  @api youtubeUrl; //= "https://www.youtube.com/@shravyaparusha";
  @api trailheadUrl; //=
  // "https://www.salesforce.com/trailblazer/j6upx8b56wd5ykemob";
  @api blogUrl; //=
  //"https://shravyaportfolio-a-dev-ed.develop.lightning.force.com/";

  userPic = `${PortfolioAssets}/PortfolioAssets/userPic.png`;
  linkedin = `${PortfolioAssets}/PortfolioAssets/Social/linkedin.svg`;
  youtube = `${PortfolioAssets}/PortfolioAssets/Social/youtube.svg`;
  github = `${PortfolioAssets}/PortfolioAssets/Social/github.svg`;
  twitter = `${PortfolioAssets}/PortfolioAssets/Social/twitter.svg`;
  trailhead = `${PortfolioAssets}/PortfolioAssets/Social/trailhead1.svg`;
  blog = `${PortfolioAssets}/PortfolioAssets/Social/blogger.svg`;

  @wire(getRecord, {
    recordId: "$recordId",
    fields: [FULLNAME, COMPANY_NAME, COMPANY_LOCATION, DESIGNATION],
  })
  portfolioData;
  //portfolioHandler({ data, error }) {
  // if (data) {
  //  console.log("record Data", JSON.stringify(data));
  // }
  // if (error) {
  //   console.error("error", error);
  // }
  // } //we used this just for reference that what kind of data is coming and why we used wire as a function//
  //After that we move to a wire as a property because wire as a property can easily use with the getFieldValue method//

  get fullName() {
    return getFieldValue(this.portfolioData.data, FULLNAME);
  }
  get companyName() {
    return getFieldValue(this.portfolioData.data, COMPANY_NAME);
  }
  get companyLocation() {
    return getFieldValue(this.portfolioData.data, COMPANY_LOCATION);
  }
  get designation() {
    return getFieldValue(this.portfolioData.data, DESIGNATION);
  }
}
