import { LightningElement, api } from "lwc";
import PortfolioAssets from "@salesforce/resourceUrl/PortfolioAssets";
export default class PortfolioUserStats extends LightningElement {
  trailheadRankImg;
  @api badges; //= "5+";
  @api points; //= "100+";
  @api trails; //= "4+";
  @api rank;

  renderedCallback() {
    if (this.rank) {
      let url = `${PortfolioAssets}/PortfolioAssets/Ranks/${this.rank}.png`;
      this.trailheadRankImg = url;
    }
  }
}
