import { LightningElement, api } from "lwc";

export default class PortfolioStringToHtml extends LightningElement {
  @api content;
  isLoaded = false;
  // eslint-disable-next-line consistent-return
  renderedCallback() {
    if (this.isLoaded) {
      return false;
    }
    if (this.content) {
      this.isLoaded = true;
      const container = this.template.querySelector(".htmlContainer");
      // eslint-disable-next-line @lwc/lwc/no-inner-html
      container.innerHTML = this.content;
    }
  }
}
