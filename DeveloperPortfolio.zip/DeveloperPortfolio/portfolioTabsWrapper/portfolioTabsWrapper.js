import { LightningElement, api } from "lwc";

export default class PortfolioTabsWrapper extends LightningElement {
  @api recordId; //= "a0Aaj000000wuY6EAI";
  @api objectApiName; //= "Portfolio__c";
}
